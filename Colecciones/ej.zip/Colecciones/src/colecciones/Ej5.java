/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones;

import colecciones.Servicios.Servicio5;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

/**
 *
 * @author Samuel
 */
public class Ej5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Servicio5 aux = new Servicio5();
        Scanner valor = new Scanner(System.in).useDelimiter("\n");
        TreeSet<String> paiss = new TreeSet();
        char letra;
        paiss = aux.crearPais();
        System.out.println("Desea ingresar pais: s/n");
        letra = valor.next().charAt(0);
        while (letra == 's') {
            paiss = aux.crearPais();
            System.out.println("Desea ingresar pais:  s/n");
            letra = valor.next().charAt(0);
        }
        System.out.println(paiss.toString());       
        System.out.println("Desea eliminar un pais: s/n");
        letra = valor.next().charAt(0);
        if(letra=='s'){
            System.out.println("Ingrese pais: ");
            String paisEliminar=valor.next();   
            if(paiss.contains(paisEliminar)){
                paiss.remove(paisEliminar);
            }else{
                System.out.println("No se encontro el pais");
            }
        }else{
            System.out.println("No se quiere eliminar pais");
        }
                  System.out.println(paiss.toString());        
    }
}
