/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class Colecciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {     
         Scanner leer = new Scanner(System.in);
        ArrayList<String> Perros = new ArrayList();
        String aux;
        do {
            System.out.println("ingrese una raza de perros");
            Perros.add(leer.nextLine());
            do {
                System.out.println("desea ingresar otra raza? si o no");
                aux = leer.nextLine();
            } while (!(aux.equals("si")) && !(aux.equals("no")));
        } while (aux.equals("si"));
           System.out.println(Perros.toString());
    }    
}

