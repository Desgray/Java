/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones;

import colecciones.Servicios.ServicioEj6;
import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class Ej6 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Integer key;
        Scanner valor = new Scanner(System.in);
        ServicioEj6 aux = new ServicioEj6();
        int opc;
        do {
            System.out.println("1.Crear producto.\n"
                    + "2.Modificar precio.\n"
                    + "3.Eliminar.\n"
                    + "4.Mostrar.\n"
                    + "5.Salirs.");
            opc = valor.nextInt();
            switch (opc) {
                case 1:
                    aux.crearObjeto();
                    break;
                case 2:
                    System.out.println("Ingrese la llave del producto a modificar: ");
                    key = valor.nextInt();
                    aux.modificarPrecio(key);
                    break;
                case 3:
                    System.out.println("Ingrese la llave del producto a modificar: ");
                    key = valor.nextInt();
                    aux.eliminar(key);
                    break;
                case 4:
                    aux.mostrar();
                    break;
                case 5:
                    System.out.println("Saliste");
                    break;
            }
        } while (opc != 5);
    }
}
