/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones.Servicios;

import java.util.Scanner;
import java.util.TreeSet;

/**
 *
 * @author Samuel
 */
public class Servicio5 {
    TreeSet<String> pais = new TreeSet();
    Scanner valor = new Scanner(System.in);
    
    public TreeSet<String> crearPais(){                    
            char aux;            
                   System.out.println("Ingrese pais");                 
                   pais.add(valor.nextLine());                                                        
                   return pais;
    }    
    public void eliminar(String paiss){
            
    }
}

