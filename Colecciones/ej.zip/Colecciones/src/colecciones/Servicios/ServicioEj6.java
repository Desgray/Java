package colecciones.Servicios;

import colecciones.Entidad.Producto;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class ServicioEj6 {
    Scanner valor = new Scanner(System.in).useDelimiter("\n");
    HashMap<Integer, Producto> producto = new HashMap();
    Producto aux;
    public void crearObjeto() {
       // Scanner p = new Scanner(System.in).useDelimiter("\n");
        char aux2;
        do {
            System.out.println("Ingrese nombre del producto: ");
            String nomb = valor.next();        
            System.out.println("Ingrese precio: ");
            Integer precio = valor.nextInt();
            System.out.println("Ingrese la llave del producto: ");
            Integer llave = valor.nextInt();
            aux = new Producto(precio, nomb);
            producto.put(llave, aux);
            System.out.println("Desea ingresar otro producto  s/n");
            aux2 = valor.next().charAt(0);
        } while (aux2 == 's');
    }

    public void modificarPrecio(Integer key) {
        Producto aux2;
        Integer prec;
        System.out.println("Ingrese el precio: ");
        prec = valor.nextInt();
        if (producto.containsKey(key)) {
            aux2 = new Producto(prec, aux.getNombre());
            producto.put(key, aux2);
        }
    }

    public void eliminar(Integer key) {
        producto.remove(key);
    }

    public void mostrar() {
        for (Map.Entry<Integer, Producto> entry : producto.entrySet()) {
            Integer key = entry.getKey();
            Producto value = entry.getValue();
            System.out.println("Llave: " + key + " Producto: " + value);
        }
    }
}
