/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones;

import colecciones.Servicios.PeliculaServicio;

/**
 *
 * @author Samuel
 */
public class Ej4 {

    public static void main(String[] args) {
        PeliculaServicio aux = new PeliculaServicio();
        aux.crearPelicula();
        aux.mostrar();
        aux.mayor1Hora();
        aux.OrdenarHoraMenorMayor();
        aux.OrdenarHoraMayorMenor();
        aux.OrdenarTitulo();
        aux.OrdenarDirector();
    }

}
