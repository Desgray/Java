/*
Tipos de variables
    byte=valores enteros desde -128 al 127
    short=enteros desde -32.768 al 32.767
    int=entero desde -2,147,483,648 al  2,147,483,64
    long=desde  -9,223,372,036,854,775,808 al  -9,223,372,036,854,775,807
    float=numero con coma precision simple
    double=numero con coma precision doble
    boolean=verdadero o falso
    char=caracteres
    String=cadena

Funciones
    System.out.println("")  imprime un mensaje   // usar sout + tab 
    Scanner var = new Scanner(System.in)  // leer valores
    para usar scanner hay que importar la libreria java.util.Scanner con import java.util.Scanner;
    declaro antes num
    num = var.nextInt()   // enteros
    num = var.nextDouble  // reales
    num = var.nextLine()  //cadenas

Estrucuturas de control
////////////////////////
    if(){
}
///////////////////////
    if(){
    
    }else{
}
//////////////////////
if(){

}else if(){

}else
///////////////////////


Condicionales
    y = &&
    o = ||
    Negacion = !


Switch(){
case 1 :
        break;
case 2:
        break;
default:
    }


Saltos
    break=En el momento que se ejecuta la instrucción break, el control del programa sale de la estructura en la que se encuentra contenida y
continua con el programa.
    continue=La sentencia continue corta la iteración en donde se encuentra el continue, pero en lugar de salir del bucle, continúa con la siguiente iteración.


Estructura repetitivas

While(){

}

do{

}while();

for(i=0; i<var,i++){

}


Funciones
    [acceso][modificador][tipo] indentificador(parametros)
{           return valor}

ej: 
 public static int suma(int a,b){
    int suma
    suma=a+b
    return suma
}
Acciones 
[acceso][modificador] void indentificador(parametros)
ej:
public static void suma(int a,b,sum){
    suma=a+b
    sout(suma)
}

arreglos
vectores: 
    tipo[] identificador = new tipo[tamaño];
matriz:
    tipo[][] identificador = new tipo[fila][columna]
*/


package javaintroduction;

import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class JavaIntroduction {
  
    public static void main(String[] args) {
                 //Codigo//
       
        
                 // chequea que tipo de bomba es //
       /*Scanner valor = new Scanner(System.in);
       int tipoMotor;
       System.out.println("Ingrese un valor entre 1 y 4 ");
       tipoMotor=valor.nextInt();
       switch(tipoMotor){
           case 1:
                    System.out.println("La bomba es una bomba de agua");
                    break;
           case 2:
                    System.out.println("La bomba es una bomba de gasolina");
                    break;
           case 3:
                    System.out.println("La bomba es una bomba de hormigon");
                    break;
           case 4:  
                    System.out.println("La bomba es una bomba de pasta alimenticia");
                    break;
           default:
                    System.out.println("No existe valor");
       }*/
        //                                                  //
    
    // chequea nota  //    
    /*
    Scanner valor = new Scanner(System.in);
    int nota;
    System.out.println("Ingrese nota: ");
    nota=valor.nextInt();
    while(nota>10 || nota<0){
        System.out.println("Ingrese nota: ");
        nota=valor.nextInt();
    }
    */
    //               //
    
    /*Scanner valor = new Scanner(System.in);
    int nota,l,sum;
    l=0;
    sum=0;
    do{
        System.out.println("Ingrese nota: ");
        nota=valor.nextInt();
        if(nota<0){
            continue;
        }else{
            sum=sum+nota;
          };
        l++;
    }while(nota!=0 && l<20 );
    
        System.out.println(sum);
   
    */
   
    }
}