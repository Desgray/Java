/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package extra.Servicio;

import extra.Entidad.Tiempo;
import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class ServicioTiempo {

    Scanner valor = new Scanner(System.in);

    public Tiempo Hora() {
        Tiempo time = new Tiempo();
        System.out.println("Ingrese la hora: ");
        time.setHora(valor.nextInt());
        System.out.println("Ingrese los minutos: ");
        time.setMinutos(valor.nextInt());
        System.out.println("Ingrese los segundo: ");
        time.setSegundo(valor.nextInt());
        return time;
    }

    public Tiempo ajustar(Tiempo time) {

        if (time.getSegundo() < 60) {
            time.setSegundo(time.getSegundo());
        } else {
            do {
                time.setSegundo(time.getSegundo() - 60);
                time.setMinutos(time.getMinutos() + 1);
            } while (time.getSegundo() >= 60);
        }

        if (time.getMinutos() < 60) {
            time.setMinutos(time.getMinutos());
        } else {
            do {
                time.setMinutos(time.getMinutos()-60);
                time.setHora(time.getHora()+1);
            } while (time.getMinutos() >= 60);
        } 
        
        if(time.getHora()<24){
            time.setHora(time.getHora());
        }else{
            time.setHora(time.getHora()-24);
        }
        return time;
    }
}
