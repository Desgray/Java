/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package extra.Servicio;

import extra.Entidad.Fraccion;
import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class ServicoFracciones {

    Scanner valor = new Scanner(System.in);

    public Fraccion crearFracion() {
        Fraccion num = new Fraccion();
        System.out.println("Ingrese numero numerador: ");
        num.setNumerador(valor.nextInt());
        System.out.println("Ingrese denominador: ");
        num.setDenominador(valor.nextInt());
        while (num.getDenominador() == 0) {
            System.out.println("Ingrese denominador: ");
            num.setDenominador(valor.nextInt());
        }
        return num;
    }

    public void calculadora(Fraccion num1, Fraccion num2) {
        Fraccion result = new Fraccion();
        int op;
        do {
            System.out.println("MENU");
            System.out.println("1.Suma");
            System.out.println("2.Resta");
            System.out.println("3.Multiplicacion");
            System.out.println("4.Division");
            System.out.println("5.Salir");
            op = valor.nextInt();
            switch (op) {
                case 1:
                    int producto = num1.getDenominador() * num2.getDenominador();
                    result.setDenominador(producto);
                    result.setNumerador(((producto / num1.getDenominador()) * num1.getNumerador()) + ((producto / num2.getDenominador()) * num2.getNumerador()));
                    if (result.getNumerador() % result.getDenominador() == 0) {
                        result.setNumerador(result.getNumerador() / result.getDenominador());
                        result.setDenominador(result.getDenominador() / result.getDenominador());
                    }
                    System.out.println(result.toString());
                    break;
                case 2:
                    int producto2 = num1.getDenominador() * num2.getDenominador();
                    result.setDenominador(producto2);
                    result.setNumerador(((producto2 / num1.getDenominador()) * num1.getNumerador()) - ((producto2 / num2.getDenominador()) * num2.getNumerador()));
                    if (result.getNumerador() % result.getDenominador() == 0) {
                        result.setNumerador(result.getNumerador() / result.getDenominador());
                        result.setDenominador(result.getDenominador() / result.getDenominador());
                    }
                    System.out.println(result.toString());
                    break;
                case 3:

                    result.setNumerador(num1.getNumerador() * num2.getNumerador());
                    result.setDenominador(num1.getDenominador() * num2.getDenominador());
                    if (result.getNumerador() % result.getDenominador() == 0) {
                        result.setNumerador(result.getNumerador() / result.getDenominador());
                        result.setDenominador(result.getDenominador() / result.getDenominador());
                    }
                    System.out.println(result.toString());
                    break;
                case 4:
                    result.setNumerador(num1.getNumerador() * num2.getDenominador());
                    result.setDenominador(num2.getNumerador() * num1.getDenominador());
                    if (result.getNumerador() % result.getDenominador() == 0) {
                        result.setNumerador(result.getNumerador() / result.getDenominador());
                        result.setDenominador(result.getDenominador() / result.getDenominador());
                    }
                    System.out.println(result.toString());
                    break;
                case 5:
                    System.out.println("Saliste");
                    break;
                default:
                    System.out.println("Opcion incorrecta");
                    break;
            }
        } while (op != 5);

    }
}
