/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package extra.Servicio;

import extra.Entidad.Fecha;
import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class ServicioFecha {

    String arreglo[] = {"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"};

    Scanner valor = new Scanner(System.in);

    public Fecha crearFecha() {
        Fecha fecha = new Fecha();
        System.out.println("Ingrese un año: ");
        int aux = valor.nextInt();
        System.out.println("Ingrese mes: ");
        fecha.setMes(valor.nextInt());
        System.out.println("Ingrese dia: ");
        fecha.setDia(valor.nextInt());
        if ((aux >= 1900 && aux <= 2021)) {
            System.out.println("Fecha correcta");
            fecha.setAnio(aux);
        } else {
            System.out.println("Fecha incorrecta");
        }
        return fecha;
    }

    public boolean bisiesto(Fecha fecha) {
        boolean aux;
        aux = (((fecha.getAnio() % 400 == 0 || (fecha.getAnio() % 4 == 0) && (fecha.getAnio() % 100 != 0))));
        return aux;
    }

    public void cantDia(Fecha fecha) {
        switch (fecha.getMes()) {
            case 1:
                System.out.println(arreglo[0]);
                System.out.println("Tiene 31 dias");
                break;
            case 2:
                System.out.println(arreglo[1]);
                if (bisiesto(fecha) == true) {
                    System.out.println("Tiene 29 dias");
                } else {
                    System.out.println("Tiene 28 dias");
                }
                break;
            case 3:
                System.out.println(arreglo[2]);
                System.out.println("Tiene 31 dias");
                break;
            case 4:
                System.out.println(arreglo[3]);
                System.out.println("Tiene 30 dias");
                break;
            case 5:
                System.out.println(arreglo[4]);
                System.out.println("Tiene 31 dias");
                break;
            case 6:
                System.out.println(arreglo[5]);
                System.out.println("Tiene 30 dias");
                break;
            case 7:
                System.out.println(arreglo[6]);
                System.out.println("Tiene 31 dias");
                break;
            case 8:
                System.out.println(arreglo[7]);
                System.out.println("Tiene 31 dias");
                break;
            case 9:
                System.out.println(arreglo[8]);
                System.out.println("Tiene 30 dias");
                break;
            case 10:
                System.out.println(arreglo[9]);
                System.out.println("Tiene 31 dias");
                break;
            case 11:
                System.out.println(arreglo[10]);
                System.out.println("Tiene 30 dias");
                break;
            case 12:
                System.out.println(arreglo[11]);
                System.out.println("Tiene 31 dias");
                break;
        }
    }

    public void diaAnterior(Fecha fecha) {
        switch (fecha.getMes()) {
            case 1:
                System.out.println(arreglo[0]);
                if (fecha.getDia() == 1) {
                    fecha.setDia(31);
                    fecha.setMes(11);
                    fecha.setAnio(fecha.getAnio() - 1);
                } else {
                    fecha.setDia(fecha.getDia() - 1);
                }             
                break;
            case 2:
                System.out.println(arreglo[1]);
                if (fecha.getDia() == 1) {
                    fecha.setDia(31);
                    fecha.setMes(0);
                } else {
                    fecha.setDia(fecha.getDia() - 1);
                }
                break;
            case 3:
                System.out.println(arreglo[2]);
                if (bisiesto(fecha)) {
                    if (fecha.getDia() == 1) {
                        fecha.setDia(29);
                        fecha.setMes(1);
                    } else {
                        fecha.setDia(fecha.getDia() - 1);
                    }
                } else {
                    if (fecha.getDia() == 1) {
                        fecha.setDia(28);
                        fecha.setMes(1);
                    } else {
                        fecha.setDia(fecha.getDia() - 1);
                    }
                }
                break;
            case 4:
                System.out.println(arreglo[3]);
                if (fecha.getDia() == 1) {
                    fecha.setDia(30);
                    fecha.setMes(2);
                } else {
                    fecha.setDia(fecha.getDia() - 1);
                }
                break;
            case 5:
                System.out.println(arreglo[4]);
                if (fecha.getDia() == 1) {
                    fecha.setDia(30);
                    fecha.setMes(3);
                } else {
                    fecha.setDia(fecha.getDia() - 1);
                }
                break;
            case 6:
                System.out.println(arreglo[5]);
                if (fecha.getDia() == 1) {
                    fecha.setDia(31);
                    fecha.setMes(4);
                } else {
                    fecha.setDia(fecha.getDia() - 1);
                }
                break;
            case 7:
                System.out.println(arreglo[6]);
                if (fecha.getDia() == 1) {
                    fecha.setDia(30);
                    fecha.setMes(5);
                } else {
                    fecha.setDia(fecha.getDia() - 1);
                }
                break;
            case 8:
                System.out.println(arreglo[7]);
                if (fecha.getDia() == 1) {
                    fecha.setDia(31);
                    fecha.setMes(6);
                } else {
                    fecha.setDia(fecha.getDia() - 1);
                }
                break;
            case 9:
                System.out.println(arreglo[8]);
                if (fecha.getDia() == 1) {
                    fecha.setDia(31);
                    fecha.setMes(7);
                } else {
                    fecha.setDia(fecha.getDia() - 1);
                }
                break;
            case 10:
                System.out.println(arreglo[9]);
                if (fecha.getDia() == 1) {
                    fecha.setDia(30);
                    fecha.setMes(8);
                } else {
                    fecha.setDia(fecha.getDia() - 1);
                }
                break;
            case 11:
                System.out.println(arreglo[10]);
                if (fecha.getDia() == 1) {
                    fecha.setDia(31);
                    fecha.setMes(9);
                } else {
                    fecha.setDia(fecha.getDia() - 1);
                }
                break;
            case 12:
                System.out.println(arreglo[11]);
                if (fecha.getDia() == 1) {
                    fecha.setDia(30);
                    fecha.setMes(10);
                } else {
                    fecha.setDia(fecha.getDia() - 1);
                }
                break;
        }
            System.out.println(fecha.toString());
    }
    
    
    public void diaPosterior(Fecha fecha) {
        switch (fecha.getMes()) {
            case 1:
                System.out.println(arreglo[0]);
                if (fecha.getDia() == 31) {
                       fecha.setDia(1);
                       fecha.setMes(1);                       
                } else {
                        fecha.setDia(fecha.getDia()+1);
                }        
                break;
            case 2:
               if (bisiesto(fecha)) {
                    if (fecha.getDia() == 29) {
                        fecha.setDia(1);
                        fecha.setMes(2);
                    } else {
                        fecha.setDia(fecha.getDia() + 1);
                    }
                } else {
                    if (fecha.getDia() == 28) {
                        fecha.setDia(1);
                        fecha.setMes(2);
                    } else {
                        fecha.setDia(fecha.getDia() + 1);
                    }
                }
                break;
            case 3:
                System.out.println(arreglo[2]);              
                    if (fecha.getDia() == 31) {
                        fecha.setDia(1);
                        fecha.setMes(3);
                    } else {
                        fecha.setDia(fecha.getDia() + 1);
                    }               
                break;
            case 4:
                System.out.println(arreglo[3]);
                if (fecha.getDia() == 30) {
                        fecha.setDia(1);
                        fecha.setMes(4);
                    } else {
                        fecha.setDia(fecha.getDia() + 1);
                    }               
                break;
            case 5:
                System.out.println(arreglo[4]);
                 if (fecha.getDia() == 31) {
                        fecha.setDia(1);
                        fecha.setMes(5);
                    } else {
                        fecha.setDia(fecha.getDia() + 1);
                    }               
                break;
            case 6:
                System.out.println(arreglo[5]);
                if (fecha.getDia() == 30) {
                        fecha.setDia(1);
                        fecha.setMes(6);
                    } else {
                        fecha.setDia(fecha.getDia() + 1);
                    }               
                break;
            case 7:
                System.out.println(arreglo[6]);
                if (fecha.getDia() == 31) {
                        fecha.setDia(1);
                        fecha.setMes(7);
                    } else {
                        fecha.setDia(fecha.getDia() + 1);
                    }               
                break;
            case 8:
                System.out.println(arreglo[7]);
                if (fecha.getDia() == 31) {
                        fecha.setDia(1);
                        fecha.setMes(8);
                    } else {
                        fecha.setDia(fecha.getDia() + 1);
                    }               
                break;
            case 9:
                System.out.println(arreglo[8]);
                if (fecha.getDia() == 30) {
                        fecha.setDia(1);
                        fecha.setMes(9);
                    } else {
                        fecha.setDia(fecha.getDia() + 1);
                    }               
                break;
            case 10:
                System.out.println(arreglo[9]);
                 if (fecha.getDia() == 31) {
                        fecha.setDia(1);
                        fecha.setMes(10);
                    } else {
                        fecha.setDia(fecha.getDia() + 1);
                    }               
                break;
            case 11:
                System.out.println(arreglo[10]);
                if (fecha.getDia() == 30) {
                        fecha.setDia(1);
                        fecha.setMes(11);
                    } else {
                        fecha.setDia(fecha.getDia() + 1);
                    }               
                break;
            case 12:
                System.out.println(arreglo[0]);
                if (fecha.getDia() == 31) {
                        fecha.setDia(1);
                        fecha.setMes(0);
                        fecha.setAnio(fecha.getAnio()+1);
                    } else {
                        fecha.setDia(fecha.getDia() + 1);
                    }               
                break;
        }
            System.out.println(fecha.toString());
    }
    
}
