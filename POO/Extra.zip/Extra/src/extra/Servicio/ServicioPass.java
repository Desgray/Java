package extra.Servicio;

import extra.Entidad.Pass;
import java.util.Scanner;

public class ServicioPass {

    Scanner valor = new Scanner(System.in);

    public Pass usuario() {
        Pass user = new Pass();
        user.setPass("xxx");
        user.setNom("nombre");
        user.setDni(00000000);
        return user;
    }

    public Pass crearPass(Pass user) {
        String auxPass;
        int aux;
        do {
            System.out.println("Ingrese su contraseña: ");
            auxPass = valor.nextLine();
            aux = auxPass.length();
        } while (aux != 10);
        user.setPass(auxPass);
        return user;
    }

    public String analizarPass(Pass user) {
        String msg = null;
        int contz = 0;
        int conta = 0;
        boolean bandera = true;
        for (int i = 0; i < user.getPass().length(); i++) {
            switch (user.getPass().charAt(i)) {
                case 'z':
                    contz++;
                    break;
                case 'a':
                    conta++;
                    break;
            }
        }
        if (contz >= 1 && conta >= 2) {
            msg = "Nivel alto";
        } else if (contz >= 1 && conta <= 1) {
            msg = "Nivel medio";
        } else {
            msg = "Nivel bajo";
        }
        return msg;
    }

    public boolean modificar(Pass user) {
        String userAux;
        int intentos = 2;
        boolean aux = false;
        System.out.println("Valide la contraseña: ");
        userAux = valor.nextLine();
        System.out.println(userAux);
        if (userAux.equals(user.getPass())) {
            System.out.println("Contraseña correcta");
            aux = true;
        } else {
            while (intentos <= 3) {
                System.out.println("Valide la contraseña: ");
                userAux = valor.nextLine();
                intentos++;
            }
            System.out.println("Acceso denegado");
        }
        return aux;
    }

    public Pass modificarNombre(Pass user) {
        System.out.println("Ingrese el nombre: ");
        user.setNom(valor.nextLine());
        return user;
    }

    public Pass modificarDni(Pass user) {
        System.out.println("Ingrese el dni: ");
        user.setDni(valor.nextInt());
        return user;
    }

    public void menu() {
        Pass user = new Pass();
        crearPass(user);
        String passAux;
        boolean aux = modificar(user);
        int op = 0;
        do {
            if (aux) {
                System.out.println("MENU");
                System.out.println("1.Cambiar nombre");
                System.out.println("2.Cambiar contraseña");
                System.out.println("3.Cambiar DNI");
                System.out.println("4.Mostrar nivel de contraseña");
                System.out.println("5.Salir");
                op = valor.nextInt();
                valor.nextLine();
                switch (op) {
                    case 1:
                        modificarNombre(user);
                        break;
                    case 2:
                        System.out.println("Ingrese contraseña antigua");
                        passAux = valor.nextLine();
                        if (passAux.equals(user.getPass())) {
                            crearPass(user);
                        } else {
                            System.out.println("Contraseña incorrecta");
                        }
                        break;
                    case 3:
                        modificarDni(user);
                        break;
                    case 4:
                        System.out.println(analizarPass(user));
                        break;
                    case 5:
                        System.out.println("Saliste");
                        break;
                    default:
                        System.out.println("Opcion no valida");
                        break;
                }
            }
        } while (op != 5);
        System.out.println(user.toString());
    }
}
