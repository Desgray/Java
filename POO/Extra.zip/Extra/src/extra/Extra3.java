package extra;

import extra.Entidad.Pass;
import extra.Servicio.ServicioPass;

public class Extra3 {

    public static void main(String[] args) {
        ServicioPass aux = new ServicioPass();    
       aux.menu();
    }

}
