/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package extra;

import extra.Entidad.Tiempo;
import extra.Servicio.ServicioTiempo;
import java.util.Arrays;

/**
 *
 * @author Samuel
 */
public class Extra2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ServicioTiempo aux = new ServicioTiempo();
        Tiempo time = aux.Hora();
        System.out.println(aux.ajustar(time).toString());
    }
    
}
