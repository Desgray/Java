package extra.Entidad;


public class Pass {
    private String pass;
    private String nom;
    private int dni;

    public Pass(String pass, String nom, int dni) {
        this.pass = pass;
        this.nom = nom;
        this.dni = dni;
    }

    public Pass() {
    
    }

    public String getPass() {
        return pass;
    }

    public String getNom() {
        return nom;
    }

    public int getDni() {
        return dni;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    @Override
    public String toString() {
        return "{" + "pass=" + pass + ", nom=" + nom + ", dni=" + dni + '}';
    }        
}
