/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package extra.Entidad;

/**
 *
 * @author Samuel
 */
public class Tiempo {
    public int hora,minutos,segundo;

    public Tiempo() {
    }

    public Tiempo(int hora, int minutos, int segundo) {
        this.hora = hora;
        this.minutos = minutos;
        this.segundo = segundo;
    }

    public int getHora() {
        return hora;
    }

    public int getMinutos() {
        return minutos;
    }

    public int getSegundo() {
        return segundo;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public void setSegundo(int segundo) {
        this.segundo = segundo;
    }

    @Override
    public String toString() {
        return "Tiempo{" + "hora=" + hora + ", minutos=" + minutos + ", segundo=" + segundo + '}';
    }
    
    
}
