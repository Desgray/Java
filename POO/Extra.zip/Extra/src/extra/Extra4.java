/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package extra;

import extra.Entidad.Fecha;
import extra.Servicio.ServicioFecha;
import java.util.Scanner;

public class Extra4 {
  
    public static void main(String[] args) {
         Scanner valor = new Scanner(System.in);
        ServicioFecha aux = new ServicioFecha();
        Fecha fecha=aux.crearFecha();
        int op;
        System.out.println("Menu");
        System.out.println("1.Cantidad de dias");
        System.out.println("2.Fecha anterior");
        System.out.println("3.Fecha posterior");      
        op=valor.nextInt();
        switch (op) {
            case 1: 
                      aux.cantDia(fecha);
                      break;
            case 2: 
                aux.diaAnterior(fecha);
                break;
            case 3: 
                    aux.diaPosterior(fecha);    
        }        
    }
    
}
