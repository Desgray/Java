/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package extra;

import extra.Entidad.Fraccion;
import extra.Servicio.ServicoFracciones;

public class Extra {

    public static void main(String[] args) {
        ServicoFracciones aux = new ServicoFracciones();
        Fraccion num1 = aux.crearFracion();
         Fraccion num2 = aux.crearFracion();
        System.out.println("Fraccion 1: "+num1.toString());
        System.out.println("Fraccion 2: "+num2.toString());
        aux.calculadora(num1, num2);
    }

}
