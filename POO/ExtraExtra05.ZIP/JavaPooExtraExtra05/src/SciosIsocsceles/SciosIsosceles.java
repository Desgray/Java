
package SciosIsocsceles;

import EntidadesIsosceles.EntidadesIsosceles;
import java.util.Scanner;


public class SciosIsosceles {
    public EntidadesIsosceles crear(){
    Scanner leer = new Scanner(System.in);
    EntidadesIsosceles a1 = new EntidadesIsosceles();
        System.out.println("Ingrese el lado A");
        a1.setLadoA(leer.nextInt());
        System.out.println("Ingrese el lado B");
        a1.setLadoB(leer.nextInt());
        System.out.println("Ingrese la base");
        a1.setBase(leer.nextInt());
    
    return a1;
    }
    
    public int calcularArea(EntidadesIsosceles a1){
    
        int area = (a1.getBase()*a1.getLadoA())/2;
        
        
        return area;
    }
    
    public int calcularPermietro (EntidadesIsosceles a1){
    
        int perimetro = (2*a1.getLadoA()) + a1.getBase();
        
        return perimetro;
    }
    
   public void compara(EntidadesIsosceles a1){
   
       int aux= 0;
       int mayor = 0;
       int areas [] = new int[4];
       for (int i = 0; i < 4; i++) {
           a1=crear();
          aux = calcularArea(a1); 
           if (aux>mayor) {
               mayor = aux;
           }else{
           
               mayor=mayor;
           }
            System.out.println("el area es: " + calcularArea(a1));
            System.out.println("el perimetro es: " + calcularPermietro(a1));
            System.out.println("El mayor area es: " + mayor);
       }
      
   }
    
}
