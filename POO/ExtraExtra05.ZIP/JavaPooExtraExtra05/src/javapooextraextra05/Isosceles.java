
package javapooextraextra05;

import EntidadesIsosceles.EntidadesIsosceles;
import SciosIsocsceles.SciosIsosceles;


public class Isosceles {

    public static void main(String[] args) {
       SciosIsosceles a1 = new SciosIsosceles();
       EntidadesIsosceles A = new EntidadesIsosceles();
       a1.compara(A);
       
       
    }
    
}
