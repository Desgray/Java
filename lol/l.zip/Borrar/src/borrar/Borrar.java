/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package borrar;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeSet;


/**
 *
 * @author Samuel
 */
public class Borrar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    ArrayList<String> personass = new ArrayList();
    HashMap<Integer, String> personas = new HashMap();
    String n1 = "Albus";
    String n2 = "Severus";
    personas.put(1,n1);
    personas.put(2,n2);
    }
}
